"use client"

import { useState } from "react"
import Header from "@/components/Header"
import Sidebar from "@/components/Sidebar"
import MainContent from "@/components/MainContent"
import RightSidebar from "@/components/RightSidebar"
import MusicPlayer from "@/components/MusicPlayer"
import LoginModal from "@/components/LoginModal"

export default function Home() {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [loginModalOpen, setLoginModalOpen] = useState(false)
  const [currentSong, setCurrentSong] = useState({
    id: 1,
    title: "Midnight Dreams",
    artist: "Luna Eclipse",
    thumbnail: "/placeholder.svg?height=60&width=60",
    duration: "3:45",
    isPlaying: false,
  })

  return (
    <div className="h-screen flex flex-col bg-gray-900">
      <Header onLoginClick={() => setLoginModalOpen(true)} />

      <div className="flex flex-1 overflow-hidden">
        <Sidebar isOpen={sidebarOpen} onToggle={() => setSidebarOpen(!sidebarOpen)} />

        <div className="flex-1 flex overflow-hidden">
          <MainContent onSongSelect={setCurrentSong} />
          <RightSidebar currentSong={currentSong} />
        </div>
      </div>

      <MusicPlayer currentSong={currentSong} onSongChange={setCurrentSong} />

      <LoginModal isOpen={loginModalOpen} onClose={() => setLoginModalOpen(false)} />
    </div>
  )
}
