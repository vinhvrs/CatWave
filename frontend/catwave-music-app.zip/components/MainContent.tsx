"use client"

import { useState, useEffect } from "react"
import { Play, Heart, MoreHorizontal, ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

interface Song {
  id: number
  title: string
  artist: string
  thumbnail: string
  duration: string
  isPlaying: boolean
}

interface MainContentProps {
  onSongSelect: (song: Song) => void
}

const featuredPlaylists = [
  {
    id: 1,
    title: "Today's Top Hits",
    description: "The most played songs right now",
    thumbnail: "/placeholder.svg?height=200&width=200",
    songs: 50,
  },
  {
    id: 2,
    title: "Chill Indie",
    description: "Relax with these indie favorites",
    thumbnail: "/placeholder.svg?height=200&width=200",
    songs: 32,
  },
  {
    id: 3,
    title: "Electronic Vibes",
    description: "Electronic music for every mood",
    thumbnail: "/placeholder.svg?height=200&width=200",
    songs: 28,
  },
  {
    id: 4,
    title: "Acoustic Sessions",
    description: "Stripped down and beautiful",
    thumbnail: "/placeholder.svg?height=200&width=200",
    songs: 24,
  },
]

const recommendedSongs = [
  {
    id: 1,
    title: "Midnight Dreams",
    artist: "Luna Eclipse",
    thumbnail: "/placeholder.svg?height=120&width=120",
    duration: "3:45",
    isPlaying: false,
  },
  {
    id: 2,
    title: "Ocean Waves",
    artist: "Coastal Drift",
    thumbnail: "/placeholder.svg?height=120&width=120",
    duration: "4:12",
    isPlaying: false,
  },
  {
    id: 3,
    title: "Neon Lights",
    artist: "City Pulse",
    thumbnail: "/placeholder.svg?height=120&width=120",
    duration: "3:28",
    isPlaying: false,
  },
  {
    id: 4,
    title: "Forest Path",
    artist: "Nature's Call",
    thumbnail: "/placeholder.svg?height=120&width=120",
    duration: "5:01",
    isPlaying: false,
  },
]

const popularTracks = [
  {
    id: 5,
    title: "Starlight Serenade",
    artist: "Cosmic Dreams",
    thumbnail: "/placeholder.svg?height=50&width=50",
    duration: "3:33",
    isPlaying: false,
  },
  {
    id: 6,
    title: "Thunder Road",
    artist: "Electric Storm",
    thumbnail: "/placeholder.svg?height=50&width=50",
    duration: "4:07",
    isPlaying: false,
  },
  {
    id: 7,
    title: "Whispered Secrets",
    artist: "Velvet Voice",
    thumbnail: "/placeholder.svg?height=50&width=50",
    duration: "3:52",
    isPlaying: false,
  },
  {
    id: 8,
    title: "Digital Horizon",
    artist: "Synth Wave",
    thumbnail: "/placeholder.svg?height=50&width=50",
    duration: "4:25",
    isPlaying: false,
  },
]

export default function MainContent({ onSongSelect }: MainContentProps) {
  const [currentSlide, setCurrentSlide] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % featuredPlaylists.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [])

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % featuredPlaylists.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + featuredPlaylists.length) % featuredPlaylists.length)
  }

  return (
    <main className="flex-1 overflow-y-auto p-6 space-y-8">
      {/* Featured Playlists Carousel */}
      <section>
        <h2 className="text-2xl font-bold mb-6">Featured Playlists</h2>
        <div className="relative">
          <div className="overflow-hidden rounded-xl">
            <div
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              {featuredPlaylists.map((playlist) => (
                <div key={playlist.id} className="w-full flex-shrink-0">
                  <Card className="glass-effect border-gray-700 hover-lift cursor-pointer">
                    <CardContent className="p-0">
                      <div className="relative h-48 lg:h-64">
                        <img
                          src={playlist.thumbnail || "/placeholder.svg"}
                          alt={playlist.title}
                          className="w-full h-full object-cover rounded-xl"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent rounded-xl" />
                        <div className="absolute bottom-4 left-4 right-4">
                          <h3 className="text-xl font-bold mb-1">{playlist.title}</h3>
                          <p className="text-gray-300 text-sm mb-2">{playlist.description}</p>
                          <p className="text-gray-400 text-xs">{playlist.songs} songs</p>
                        </div>
                        <Button
                          size="sm"
                          className="absolute top-4 right-4 gradient-primary border-0 rounded-full w-12 h-12"
                        >
                          <Play className="w-5 h-5" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          </div>

          {/* Carousel Controls */}
          <Button
            variant="ghost"
            size="sm"
            className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 rounded-full"
            onClick={prevSlide}
          >
            <ChevronLeft className="w-5 h-5" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 rounded-full"
            onClick={nextSlide}
          >
            <ChevronRight className="w-5 h-5" />
          </Button>

          {/* Dots Indicator */}
          <div className="flex justify-center mt-4 space-x-2">
            {featuredPlaylists.map((_, index) => (
              <button
                key={index}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentSlide ? "bg-purple-500" : "bg-gray-600"
                }`}
                onClick={() => setCurrentSlide(index)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Recommended for You */}
      <section>
        <h2 className="text-2xl font-bold mb-6">Recommended for You</h2>
        <div className="flex space-x-4 overflow-x-auto pb-4">
          {recommendedSongs.map((song) => (
            <Card
              key={song.id}
              className="flex-shrink-0 w-48 glass-effect border-gray-700 hover-lift cursor-pointer group"
              onClick={() => onSongSelect(song)}
            >
              <CardContent className="p-4">
                <div className="relative mb-3">
                  <img
                    src={song.thumbnail || "/placeholder.svg"}
                    alt={song.title}
                    className="w-full h-32 object-cover rounded-lg"
                  />
                  <Button
                    size="sm"
                    className="absolute bottom-2 right-2 gradient-primary border-0 rounded-full w-10 h-10 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Play className="w-4 h-4" />
                  </Button>
                </div>
                <h3 className="font-semibold truncate mb-1">{song.title}</h3>
                <p className="text-gray-400 text-sm truncate">{song.artist}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Popular Tracks */}
      <section>
        <h2 className="text-2xl font-bold mb-6">Popular Tracks</h2>
        <div className="space-y-2">
          {popularTracks.map((track, index) => (
            <div
              key={track.id}
              className="flex items-center p-3 rounded-lg hover:bg-gray-800/50 transition-colors cursor-pointer group"
              onClick={() => onSongSelect(track)}
            >
              <span className="w-6 text-gray-400 text-sm">{index + 1}</span>
              <img
                src={track.thumbnail || "/placeholder.svg"}
                alt={track.title}
                className="w-12 h-12 rounded-lg mx-4"
              />
              <div className="flex-1 min-w-0">
                <h4 className="font-medium truncate">{track.title}</h4>
                <p className="text-gray-400 text-sm truncate">{track.artist}</p>
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
                  <Heart className="w-4 h-4" />
                </Button>
                <span className="text-gray-400 text-sm w-12 text-right">{track.duration}</span>
                <Button
                  size="sm"
                  className="gradient-primary border-0 rounded-full w-8 h-8 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Play className="w-3 h-3" />
                </Button>
                <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </main>
  )
}
