"use client"

import { Play, Pause, Heart, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface Song {
  id: number
  title: string
  artist: string
  thumbnail: string
  duration: string
  isPlaying: boolean
}

interface RightSidebarProps {
  currentSong: Song
}

const suggestedArtists = [
  {
    id: 1,
    name: "Aurora Beats",
    avatar: "/placeholder.svg?height=40&width=40",
    followers: "2.1M",
    isFollowing: false,
  },
  {
    id: 2,
    name: "Midnight Collective",
    avatar: "/placeholder.svg?height=40&width=40",
    followers: "1.8M",
    isFollowing: true,
  },
  {
    id: 3,
    name: "Echo Chamber",
    avatar: "/placeholder.svg?height=40&width=40",
    followers: "956K",
    isFollowing: false,
  },
  {
    id: 4,
    name: "Stellar Sounds",
    avatar: "/placeholder.svg?height=40&width=40",
    followers: "743K",
    isFollowing: false,
  },
]

export default function RightSidebar({ currentSong }: RightSidebarProps) {
  return (
    <aside className="hidden xl:block w-80 p-6 space-y-6">
      {/* Now Playing */}
      <Card className="glass-effect border-gray-700">
        <CardHeader>
          <CardTitle className="text-lg">Now Playing</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center space-x-3">
            <img
              src={currentSong.thumbnail || "/placeholder.svg"}
              alt={currentSong.title}
              className="w-16 h-16 rounded-lg"
            />
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold truncate">{currentSong.title}</h4>
              <p className="text-gray-400 text-sm truncate">{currentSong.artist}</p>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <Button size="sm" className="gradient-primary border-0 rounded-full w-10 h-10">
              {currentSong.isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </Button>
            <Button variant="ghost" size="sm">
              <Heart className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Suggested Artists */}
      <Card className="glass-effect border-gray-700">
        <CardHeader>
          <CardTitle className="text-lg">Suggested Artists to Follow</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {suggestedArtists.map((artist) => (
            <div key={artist.id} className="flex items-center space-x-3">
              <img src={artist.avatar || "/placeholder.svg"} alt={artist.name} className="w-10 h-10 rounded-full" />
              <div className="flex-1 min-w-0">
                <h4 className="font-medium truncate">{artist.name}</h4>
                <p className="text-gray-400 text-xs">{artist.followers} followers</p>
              </div>
              <Button
                size="sm"
                variant={artist.isFollowing ? "outline" : "default"}
                className={artist.isFollowing ? "border-gray-600" : "gradient-primary border-0"}
              >
                {artist.isFollowing ? "Following" : "Follow"}
              </Button>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card className="glass-effect border-gray-700">
        <CardHeader>
          <CardTitle className="text-lg">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button variant="outline" className="w-full justify-start border-gray-600 bg-transparent">
            <Plus className="w-4 h-4 mr-2" />
            Create Playlist
          </Button>
          <Button variant="outline" className="w-full justify-start border-gray-600 bg-transparent">
            <Heart className="w-4 h-4 mr-2" />
            Liked Songs
          </Button>
        </CardContent>
      </Card>
    </aside>
  )
}
